from flask import Flask ,render_template,jsonify

app = Flask(__name__)

@app.route("/",methods=["POST","GET"])
def home():
    
    return render_template('index.html')

@app.route("/runalgorithm/<name>",methods=["POST","GET"])
def runalgorithm(name):
    '@TODO add preprocessing methods'
    
    #fig1,fig2,accuracy = train(name)
    return jsonify({"fig1":"hello","fig2":"world","accuracy":"I am Nikhil"})
   


if __name__ == "__main__":

    app.run(host="localhost",port=5000)